import numpy as np

x = np.array([1, 2, 3])
y = np.array([4, 5, 6])
z = np.vstack((x, y))
print("x =", x)
print("y =", y)
print("z =", z)