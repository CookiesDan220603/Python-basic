import numpy as np

n = int(input("Enter n: "))
vector_x = 10 ** np.arange(1, n + 1)
print("Vector x =", vector_x)