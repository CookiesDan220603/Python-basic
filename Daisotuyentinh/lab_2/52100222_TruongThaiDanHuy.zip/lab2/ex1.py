import numpy as np
x = [1, 3, 5, 2, 9]
x_vector = np.array(x)
y = [-1, 3, 15, 27, 29]
y_vector = np.array(y)
print("Exercise 1a :")
print(x_vector)
print("************")
print("Exercise 1b : ")
print(y_vector)