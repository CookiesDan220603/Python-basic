import numpy as np
I = np.eye(5)
I = I*3
np.random.seed(1)
B =np.random.randint(-3,5 ,size=(5,6))
print(B)