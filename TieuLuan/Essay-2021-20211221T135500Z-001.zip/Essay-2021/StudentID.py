from sympy import * ## KHONG XOA
import numpy as np ## KHONG XOA 

global x, y, z, t ## KHONG XOA
x, y, z, t = symbols("x, y, z, t") ## KHONG XOA     

def req1(f, g, a):  ## KHONG XOA
    return Null

def req2(f, a, b, c):  ## KHONG XOA
    return Null

def req3(w, f1, f2, f3, a):  ## KHONG XOA
    return Null

def req4(a, b, n):  ## KHONG XOA
    return Null

def req5(f):  ## KHONG XOA
    return Null

def req6(message, x, y, z):  ## KHONG XOA
    return Null

def req7(xp, yp, xs):  ## KHONG XOA
    return Null

def req8(f, eta, xi, tol): ## KHONG XOA
    return Null

    
    
  
         